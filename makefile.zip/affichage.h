#ifndef AFFICHAGE
#define AFFICHAGE

#include "dataBuffer.h"

void affichage(oxy oxyDatas);

#endif