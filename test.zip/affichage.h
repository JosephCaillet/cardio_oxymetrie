#ifndef AFFICHAGE
#define AFFICHAGE

#include "dataBuffer.h"

void affichage(oxy oxyDatas);

void affichage2(float acr, float acir);

void printInFile(char* dataFileName, char* verrouFileName, int value1, int value2);

#endif
