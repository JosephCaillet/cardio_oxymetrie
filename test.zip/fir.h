#ifndef FIR
#define FIR

#include <stdio.h>
#include "dataBuffer.h"

void fir(DataBuffer* dataBuffer, float* acRFiltre, float* acIRFiltre);
absorp firTest(char* str);

#endif
